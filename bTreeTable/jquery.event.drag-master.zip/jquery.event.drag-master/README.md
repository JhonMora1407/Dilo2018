# jquery.event.drag for browserify

Originally from https://github.com/threedubmedia/jquery.threedubmedia
